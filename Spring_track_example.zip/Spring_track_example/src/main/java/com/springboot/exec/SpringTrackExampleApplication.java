package com.springboot.exec;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringTrackExampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringTrackExampleApplication.class, args);
	}

}
