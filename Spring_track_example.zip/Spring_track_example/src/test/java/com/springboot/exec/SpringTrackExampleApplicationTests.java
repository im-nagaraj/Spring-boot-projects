package com.springboot.exec;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringTrackExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
